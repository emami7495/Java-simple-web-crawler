package Searcher;

import java.util.Random;
import java.util.Scanner;

/**
 * Created by Mosi on 5/27/2017.
 */
public class S {
    static int p1dice1;
    static int p2dice1;
    static int position1;
    static int position2;
    static int ladders[] = {8, 15, 42, 66};
    static int laddersEnd[] = {31, 97, 81, 87};//where the ladders take u
    static int snakes[] = {24, 55, 71, 88, 99};
    static int snakesEnd[] = {1, 13, 29, 67, 6};//where the snakes take u
    static String name1;
    static String name2;
    static Scanner input = new Scanner(System.in);

    public static void main(String args[]) {
        askForName();
        p1dice1 = rollDie();
//        System.out.println(p1dice1);
        p2dice1 = rollDie();
//        System.out.println(p2dice1);
        loop();
    }

    public static void askForName() {
        System.out.println("***********************WELCOME TO SNAKES AND LADDERS**************************");

        for (int i = 0; i < 20; i++)
            System.out.print("_");
        for (int j = 1; j < 20; j++)
            System.out.println("|");

        System.out.println(" _______________________________         _______________________________");
        System.out.println("|     snake     |   snake end   |       |    ladders    |  ladders end  |");
        System.out.println("|      24       |       1       |       |      8        |       31      |");
        System.out.println("|      55       |       13      |       |      15       |       97      |");
        System.out.println("|      71       |       29      |       |      42       |       81      |");
        System.out.println("|      88       |       67      |       |      66       |       87      |");
        System.out.println("|      99       |       6       |        ------------------------------- ");
        System.out.println(" ------------------------------- ");

        System.out.println("Enter player 1's name");
        name1 = input.nextLine();
        System.out.println("Enter player 2's name");
        name2 = input.nextLine();
        System.out.println("Good Luck " + name1 + " and " + name2);
    }

    public static int rollDie() {
        Random rand = new Random();
        int result = 1 + rand.nextInt(6);
        System.out.println();
//        System.out.println("random number is :" + result);
        System.out.println();
        return result;
    }

    public static int position1(String roll) {
        System.out.println("player 1 roll, press anything");
        String str = input.next();
        p1dice1 = Integer.parseInt(roll);
        System.out.println("player1 has rolled " + p1dice1);
        position1 = position1 + p1dice1;
        System.out.println("player 1 is now at " + position1);
        return position1;
    }

    public static int position2(String roll) {
        System.out.println("player 2 rolls, press anything to begin");
        String str = input.next();
        p2dice1 = Integer.parseInt(roll);
        System.out.println("player2 has rolled " + p2dice1);
        position2 = position2 + p2dice1;
        System.out.println("player 2 is now at " + position2);
        return position2;
    }

    public static void winner() {
        if (position1 >= 100) {
            System.out.println("THE WINNER IS " + name1);
        } else if (position2 >= 100) {
            System.out.println("THE WINNER IS " + name2);
        }
    }

    public static int player1Ladders() {
        for (int i = 0; i < ladders.length; i++) {
            if (position1 == ladders[i]) {
                System.out.println("You hit a ladder! your new position is " + laddersEnd[i]);
                position1 = laddersEnd[i];
            }
        }
        return position1;
    }

    public static int player1Snakes() {
        for (int i = 0; i < snakes.length; i++) {
            if (position1 == snakes[i]) {
                System.out.println("You hit a ladder! your new position is " + snakesEnd[i]);
                position1 = snakesEnd[i];
            }
        }
        return position1;
    }

    public static int player2Ladders() {
        for (int i = 0; i < ladders.length; i++) {
            if (position2 == ladders[i]) {
                System.out.println("You hit a ladder! your new position is " + laddersEnd[i]);
                position2 = laddersEnd[i];
            }
        }
        return position2;
    }

    public static int player2Snakes() {
        for (int i = 0; i < snakes.length; i++) {
            if (position2 == snakes[i]) {
                System.out.println("You hit a ladder! your new position is " + snakesEnd[i]);
                position2 = snakesEnd[i];
            }
        }
        return position2;
    }

    public static void loop() {
        while (position1 < 100 && position2 < 100) {
            String roll1 = "";
            roll1 = String.valueOf(rollDie());
            String roll2 = "";
            roll2 = String.valueOf(rollDie());
            position1(roll1);
            player1Ladders();
            player1Snakes();
            position2(roll2);
            player2Ladders();
            player2Snakes();
            winner();
        }
    }

    public static void positionCheck() {
        if (position1 + p1dice1 > 100) {

        }
    }
}