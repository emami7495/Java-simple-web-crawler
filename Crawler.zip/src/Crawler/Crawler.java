package Crawler;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


/**
 * Created by Mosi on 2/13/2017.
 */
public class Crawler {
    public static Configs configs;
    public static UrlChecker urlChecker;
    public static Arbiter arbiter;
        //speed 4 Mgbit ps  // start 1 // end 1:46  // 10007 webpage // size 765 mgByte
    public static void main(String[] args) {
        final int depth = 1;
        //
        configs = new Configs();
        urlChecker = new UrlChecker();
        arbiter = new Arbiter();
        //
        Thread thread = new Thread(arbiter);
        thread.start();
        //
        firstInitial();
        //
        Executor executor = Executors.newFixedThreadPool(Configs.donwloaderNumber);
        //
        for (int i = 0; i < Configs.donwloaderNumber; i++) {
            Downloader downloader = new Downloader(i, depth);
            executor.execute(downloader);
        }
        //
        SaveProcessingQueues saveProcessingQueues = new SaveProcessingQueues();
        Thread saveProcessingQueuesThread = new Thread(saveProcessingQueues);
        saveProcessingQueuesThread.start();
    }

    ////////////////////////////////////
    private static void firstInitial() {
        for (int i = 0; i < Configs.seedsUrl.length; i++) {
            String str = getHost(Configs.seedsUrl[i]);
            if (str != null) {
                Host host = new Host(str);
                arbiter.hosts.add(host);
            }
        }
        arbiter.addDownloadLink(Configs.seedsUrl[0], 1);
        arbiter.addDownloadLink(Configs.seedsUrl[1], 1);
        arbiter.addDownloadLink(Configs.seedsUrl[2], 1);
        arbiter.addDownloadLink(Configs.seedsUrl[3], 1);
        arbiter.addDownloadLink(Configs.seedsUrl[4], 1);
        ///
        try {
            for (int i = 0; i < Configs.seedsUrl.length; i++) {
                ///////////////////
                Document document = Jsoup.connect(Configs.seedsUrl[i])
                        .timeout(Configs.timeOut)
                        .get();
                //
                Parser parser = new Parser(document, 1);
                Thread parserThread = new Thread(parser);
                parserThread.start();
                //
                Writer writer = new Writer(document, i, Configs.seedsUrl[i]);
                Thread writerThread = new Thread(writer);
                writerThread.start();
                //
                arbiter.PageNumber++;
                System.out.println(arbiter.PageNumber + " page downloaded");
            }
            //
        } catch (IOException e) {
            e.printStackTrace();
        }
        //
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    /////////////////////////////////////////
    public static String getHost(String url) {
        URI uri;
        try {
            url = url.replace(" ", "");//////////////////////
            uri = new URI(url);
            return uri.getHost();
        } catch (URISyntaxException e) {
            //e.printStackTrace();
        }
        return null;

    }
    //
}