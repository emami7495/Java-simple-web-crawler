package Crawler;

/**
 * Created by Mosi on 3/6/2017.
 */
public class Resume {
}
