package Crawler;

/**
 * Created by Mosi on 3/5/2017.
 */
public class Configs {
    //
    public static int fileNumbers = 10;// for indexer
    //
    public static final int timeOut = 10000;
    public static final int timeToSaveProcessingQueues = 60000;
    ///
    public static final int donwloaderNumber = 10;
    public static final int maxPageNumber = 500;
    public static final int maxDepth = 5;
    public static String[] seedsUrl;

    public Configs() {
        seedsUrl = new String[5];
        seedsUrl[0] = "http://www.zoomit.ir/";
        seedsUrl[1] = "http://p30download.com/";
        seedsUrl[2] = "http://irgs.ir/";
        seedsUrl[3] = "http://www.tebyangame.com/";
        seedsUrl[4] = "http://museum.trec.co.ir/";
    }
}
